export function validate(schema?: any, depth?: any[]): void;
export function validateArray(depth: Array<string>, propertyConfiguration: Object, key: string): void;
export class validateArray {
    private constructor();
    isValidState: boolean | undefined;
}
export function validateProperty(depth: any, propertyConfiguration: any): void;
export class validateProperty {
    private constructor();
    isValidState: boolean | undefined;
}
export function getErrorMessageFor(propertyValue: any, propertyConfiguration: Object, dType: string, depth: Array<string>, validationScope: string, validationName: string): string;
export function getGenericErrorMessage(): string;
