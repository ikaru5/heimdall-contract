export namespace validationDefinitions {
    namespace breaker {
        namespace allowBlank {
            function check({ value, config: isAllowed, dType, depth, contract }: CheckParams): boolean;
        }
        namespace on {
            export function check_1({ value, config: contextOfProperty, dType, depth, contract }: CheckParams): boolean;
            export { check_1 as check };
        }
    }
    namespace normal {
        namespace dType {
            export function check_2({ value, config: dataType, dType, depth, contract }: CheckParams): boolean;
            export { check_2 as check };
            export function message({ value, config: dataType, dType, depth, contract, customLocalization }: MessageParams): string;
        }
        namespace presence {
            export function check_3({ value, config: isRequired, dType, depth, contract }: CheckParams): boolean;
            export { check_3 as check };
            export function message_1({ value, config: isRequired, dType, depth, contract, customLocalization }: MessageParams): string;
            export { message_1 as message };
        }
        namespace absence {
            export function check_4({ value, config: mustBeAbsent, dType, depth, contract }: CheckParams): boolean;
            export { check_4 as check };
            export function message_2({ value, config: isRequired, dType, depth, contract, customLocalization }: MessageParams): string;
            export { message_2 as message };
        }
        namespace isEmail {
            export function check_5({ value, config: mustBeEmail, dType, depth, contract }: CheckParams): boolean;
            export { check_5 as check };
            export function message_3({ value, config: mustBeEmail, dType, depth, contract, customLocalization }: MessageParams): string;
            export { message_3 as message };
        }
        namespace match {
            export function check_6({ value, config: regex, dType, depth, contract }: CheckParams): boolean;
            export { check_6 as check };
            export function message_4({ value, config: regex, dType, depth, contract, customLocalization }: MessageParams): string;
            export { message_4 as message };
        }
        namespace only {
            export function check_7({ value, config: allowedValues, dType, depth, contract }: CheckParams): boolean;
            export { check_7 as check };
            export function message_5({ value, config: allowedValues, dType, depth, contract, customLocalization }: MessageParams): string;
            export { message_5 as message };
        }
        namespace strictOnly {
            export function check_8({ value, config: allowedValues, dType, depth, contract }: CheckParams): boolean;
            export { check_8 as check };
            export function message_6({ value, config: allowedValues, dType, depth, contract, customLocalization }: MessageParams): string;
            export { message_6 as message };
        }
        namespace min {
            export function check_9({ value, config: minCount, dType, depth, contract }: CheckParams): boolean;
            export { check_9 as check };
            export function message_7({ value, config: minCount, dType, depth, contract, customLocalization }: MessageParams): string;
            export { message_7 as message };
        }
        namespace max {
            export function check_10({ value, config: maxCount, dType, depth, contract }: CheckParams): boolean;
            export { check_10 as check };
            export function message_8({ value, config: maxCount, dType, depth, contract, customLocalization }: MessageParams): string;
            export { message_8 as message };
        }
    }
}
/**
 * Defines all validation functions using named parameters for improved code maintainability.
 *
 * There are following validation groups:
 *   - breaker  -  These run at the beginning and if one succeeds, the remaining validations are skipped.
 *   - normal   -  Standard validations; if one fails, the field is considered invalid.
 *
 * Each validation requires a "check" function that uses destructured named parameters:
 * check function signature: ({value, config, dType, depth, contract}) => boolean
 *
 * For better error messages instead of generic "Field invalid!", a message function can be defined.
 * Note: Message functions are not used for breaker validations.
 * message function signature: ({value, config, dType, depth, contract, customLocalization}) => string
 *
 * The parameter types live handwritten in types.d.ts:
 */
export type CheckParams = import("./types.js").CheckParams;
/**
 * Defines all validation functions using named parameters for improved code maintainability.
 *
 * There are following validation groups:
 *   - breaker  -  These run at the beginning and if one succeeds, the remaining validations are skipped.
 *   - normal   -  Standard validations; if one fails, the field is considered invalid.
 *
 * Each validation requires a "check" function that uses destructured named parameters:
 * check function signature: ({value, config, dType, depth, contract}) => boolean
 *
 * For better error messages instead of generic "Field invalid!", a message function can be defined.
 * Note: Message functions are not used for breaker validations.
 * message function signature: ({value, config, dType, depth, contract, customLocalization}) => string
 *
 * The parameter types live handwritten in types.d.ts:
 */
export type MessageParams = import("./types.js").MessageParams;
