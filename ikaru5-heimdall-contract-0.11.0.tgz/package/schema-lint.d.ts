/**
 * Schema linting for Heimdall Contracts.
 *
 * Linting runs in two phases because they need different knowledge:
 *   - structure  -  checked at construction time: dTypes, arrayOf, contract, node shapes.
 *                   These are self-contained and can fail as early as possible.
 *   - keywords   -  checked at the beginning of isValid(): every key of a property config must be a known
 *                   validation. This can not happen at construction time, because additional validations
 *                   may be inherited from a parent contract through _parseParent, which runs after construction.
 *
 * Note: like in validation-base.js all lint functions are exported and bound to the contract instance.
 * The bound version is private (starts with _). Always use the bound version!
 */
export class SchemaError extends Error {
    /**
     * @param {Array<string>} problems - list of schema problems, each with a path to the offending config
     */
    constructor(problems: Array<string>);
    problems: string[];
}
export function reportSchemaProblems(problems: Array<string>): void;
export function lintSchemaStructure(schema: Object, depth?: Array<string>, problems?: Array<string>): Array<string>;
export function lintSchemaKeywords(schema: Object, depth?: Array<string>, problems?: Array<string>): Array<string>;
