export { SchemaError };
export { contractClass } from "./contract-factory.js";
/**
 * The type vocabulary lives handwritten in types.d.ts - see doc/typescript.md
 * @typedef {import('./types.js').Options} Options
 * @typedef {import('./types.js').Schema} Schema
 * @typedef {import('./types.js').PropertyDefinition} PropertyDefinition
 * @typedef {import('./types.js').Dtype} Dtype
 * @typedef {import('./types.js').ContractConfig} ContractConfig
 * @typedef {import('./types.js').AdditionalValidations} AdditionalValidations
 * @typedef {import('./types.js').ErrorNode} ErrorNode
 * @typedef {import('./types.js').FlatError} FlatError
 * @typedef {import('./types.js').ContractClass} ContractClass
 */
/**
 * Provides a class based value holder.
 * Supports nested values.
 * !!!ATTENTION!!! 'dType' not allowed as name for a property !!!
 * dType is required and indicates what datatype is used.
 * dType can be "String", "Number", "Boolean", "Array", "Contract" or "Generic" (Generic means it doesn't matter)
 */
export default class Contract {
    /**
     * Heimdall Contract
     * @param {Options} [options]
     */
    constructor(options?: Options);
    /** @private @type {(schema?: Schema, depth?: Array<string>) => void} */
    private _validate;
    /** @private @type {(depth: Array<string>, propertyConfiguration: PropertyDefinition, key: string) => void} */
    private _validateArray;
    /** @private @type {(depth: Array<string>, propertyConfiguration: PropertyDefinition) => void} */
    private _validateProperty;
    /** @private @type {() => string} */
    private _getGenericErrorMessage;
    /** @private @type {(propertyValue: *, propertyConfiguration: PropertyDefinition, dType: Dtype, depth: Array<string>, validationScope: "normal" | "breaker", validationName: string) => string} */
    private _getErrorMessageFor;
    /** @private @type {(schema: Schema, depth: Array<string>, problems: Array<string>) => Array<string>} */
    private _lintSchemaStructure;
    /** @private @type {(schema: Schema, depth: Array<string>, problems: Array<string>) => Array<string>} */
    private _lintSchemaKeywords;
    /** @private @type {(problems: Array<string>) => void} */
    private _reportSchemaProblems;
    /** @type {ContractConfig} */
    contractConfig: ContractConfig;
    _additionalValidations: import("./types.js").AdditionalValidations;
    /** @type {Schema} */
    schema: Schema;
    /** @type {ErrorNode} */
    errors: ErrorNode;
    initNested: (() => void) | undefined;
    initAll: (() => void) | undefined;
    isValidState: boolean | undefined;
    isAssignedEmpty: boolean;
    /**
     * Return schema so the constructor can set it.
     * Override this method to define the fields of your contract - see doc/schema.md
     * @returns {Schema}
     */
    defineSchema(): Schema;
    /**
     * Hook method to add custom validations to the contract.
     * Override this method to add custom validation rules - see doc/validation/additionalValidations.md
     * @param {AdditionalValidations} [validations] - Custom validations grouped into breaker and normal
     * @returns {AdditionalValidations} The validations object with custom validation definitions
     */
    addAdditionalValidations(validations?: AdditionalValidations): AdditionalValidations;
    /**
     * Hook method
     */
    init(): void;
    /**
     * Hook method to set custom configuration for the contract.
     * Override this method to customize contract behavior and settings.
     */
    setConfig(): void;
    /**
     * Is contract valid?
     * @param {string | Array<string>} [context] - validation context(s), see doc/validation/on.md
     * @returns {boolean}
     * @throws {SchemaError} if the schema uses unknown validation keywords and strictSchema is enabled
     */
    isValid(context?: string | Array<string>): boolean;
    _keywordLintChecked: boolean | undefined;
    _validationContext: string | string[] | undefined;
    /**
     * Returns the error node at a field path - the form friendly way to read errors.
     * Array elements are addressed by their index: "items.0.name" or ["items", 0, "name"].
     * @param {string | Array<string|number>} path
     * @returns {ErrorNode | undefined} the node, or undefined if there are no errors at the path
     */
    errorsAt(path: string | Array<string | number>): ErrorNode | undefined;
    /**
     * Returns all errors as a flat list - handy for toasts, logging or summaries.
     * @param {ErrorNode} [_node] - private - used for recursion
     * @param {Array<string|number>} [_path] - private - used for recursion
     * @param {Array<FlatError>} [_out] - private - used for recursion
     * @returns {Array<FlatError>} entries with path (array indices as numbers), validation and message
     */
    flatErrors(_node?: ErrorNode, _path?: Array<string | number>, _out?: Array<FlatError>): Array<FlatError>;
    /**
     * Helper to assign a corresponding Object.
     * @param {*} inputObject - nested data, e.g. from your API or state management
     * @param {Array<string>} [_depth] - private - used for recursion
     * @param {Array<string>} [_parsedDepth] - private - used for recursion
     * @param {Schema} [_currentScope] - private - used for recursion
     */
    assign(inputObject: any, _depth?: Array<string>, _parsedDepth?: Array<string>, _currentScope?: Schema): void;
    /**
     * Helper to assign nested value.
     * @param depth - nesting Array
     * @param value - Value to assign
     * @param object - default: this - object to assign nested value
     */
    setValueAtPath(depth: any, value: any, object?: this): void;
    /**
     * Helper to gather nested value
     * @param depth
     * @param object
     * @returns {*}
     */
    getValueAtPath(depth: any, object?: this): any;
    /**
     * Helper to gather nested value from multiple paths. First found will be returned.
     * @param {Array<String>} depths
     * @param {Contract} object
     * @returns {undefined|*}
     */
    getFirstMatchingValueAtPath(depths: Array<string>, object?: Contract): undefined | any;
    /**
     * Returns clean Object with filled data for sending, according to contract schema.
     * Not safe if not validated before!
     * @param {Array<string>} [_depth] - private - used for recursion
     * @param {Schema} [_currentScope] - private - used for recursion
     * @returns {Record<string, unknown>}
     */
    toObject(_depth?: Array<string>, _currentScope?: Schema): Record<string, unknown>;
    /**
     * Returns name of a class.
     * @param className
     * @private
     */
    private _getNameOfClass;
    /**
     * Checks whether a contract class is the one an array element's arrayElementType refers to.
     * Prefers the class's static typeName (an explicit serialization identity, stable across
     * minification) and falls back to the class name for backwards compatibility.
     * @param {Function} contractClass - Contract class constructor
     * @param {string} typeName - The element's arrayElementType value
     * @returns {boolean}
     * @private
     */
    private _matchesArrayElementType;
    /**
     * Creates a nested contract instance for array elements.
     * @param {Function|Object} contractClassOrDefinition - Contract class constructor or schema definition
     * @param {Object} input - Input data to assign to the nested contract
     * @returns {Contract} The created and configured nested contract instance
     * @private
     */
    private _createNestedContractForArray;
    /**
     * Associates recursively the values to "this" by passing it to _defineProperty. (this.user.address.street = "")
     * Also prepares this.errors.
     * @param {Object} schema - the current schema level
     * @param {Array<string>} depth - the current depth path of schema (["user", "address", "street"])
     * @private
     */
    private _define;
    /**
     * Associates the value to "this" and prepares this.errors. (this.user.address.street = "")
     * @param {Array<string>} depth
     * @param {Object} config - prop config from schema
     * @private
     */
    private _defineProperty;
    /**
     * Returns a default empty value for a dType. Provide Contract-Class or schema-definition for nested empty contract!
     * @param dType
     * @param contract contract Class or definition for empty contract
     * @returns {*[]|string|*|null|[]|string|undefined}
     * @private
     */
    private _defaultEmptyValueFor;
    /**
     * Method will be run by nested Contracts on creation, assignment and validation.
     * Following tasks are implemented:
     *   * Inherit customLocalization and tryTranslateMessages
     * @param parent Parent contract instance
     * @private
     */
    private _parseParent;
    /**
     * Set validations by merging additionalValidations with base validations.
     * @private
     */
    private _setValidations;
    _validations: {
        normal: {
            dType: {
                check: ({ value, config: dataType, dType, depth, contract }: CheckParams) => boolean;
                message: ({ value, config: dataType, dType, depth, contract, customLocalization }: MessageParams) => string;
            };
            presence: {
                check: ({ value, config: isRequired, dType, depth, contract }: CheckParams) => boolean;
                message: ({ value, config: isRequired, dType, depth, contract, customLocalization }: MessageParams) => string;
            };
            absence: {
                check: ({ value, config: mustBeAbsent, dType, depth, contract }: CheckParams) => boolean;
                message: ({ value, config: isRequired, dType, depth, contract, customLocalization }: MessageParams) => string;
            };
            isEmail: {
                check: ({ value, config: mustBeEmail, dType, depth, contract }: CheckParams) => boolean;
                message: ({ value, config: mustBeEmail, dType, depth, contract, customLocalization }: MessageParams) => string;
            };
            match: {
                check: ({ value, config: regex, dType, depth, contract }: CheckParams) => boolean;
                message: ({ value, config: regex, dType, depth, contract, customLocalization }: MessageParams) => string;
            };
            only: {
                check: ({ value, config: allowedValues, dType, depth, contract }: CheckParams) => boolean;
                message: ({ value, config: allowedValues, dType, depth, contract, customLocalization }: MessageParams) => string;
            };
            strictOnly: {
                check: ({ value, config: allowedValues, dType, depth, contract }: CheckParams) => boolean;
                message: ({ value, config: allowedValues, dType, depth, contract, customLocalization }: MessageParams) => string;
            };
            min: {
                check: ({ value, config: minCount, dType, depth, contract }: CheckParams) => boolean;
                message: ({ value, config: minCount, dType, depth, contract, customLocalization }: MessageParams) => string;
            };
            max: {
                check: ({ value, config: maxCount, dType, depth, contract }: CheckParams) => boolean;
                message: ({ value, config: maxCount, dType, depth, contract, customLocalization }: MessageParams) => string;
            };
        };
        breaker: {
            allowBlank: {
                check: ({ value, config: isAllowed, dType, depth, contract }: CheckParams) => boolean;
            };
            on: {
                check: ({ value, config: contextOfProperty, dType, depth, contract }: CheckParams) => boolean;
            };
        };
    } | undefined;
}
export const ContractBase: typeof Contract;
/**
 * The type vocabulary lives handwritten in types.d.ts - see doc/typescript.md
 */
export type Options = import("./types.js").Options;
/**
 * The type vocabulary lives handwritten in types.d.ts - see doc/typescript.md
 */
export type Schema = import("./types.js").Schema;
/**
 * The type vocabulary lives handwritten in types.d.ts - see doc/typescript.md
 */
export type PropertyDefinition = import("./types.js").PropertyDefinition;
/**
 * The type vocabulary lives handwritten in types.d.ts - see doc/typescript.md
 */
export type Dtype = import("./types.js").Dtype;
/**
 * The type vocabulary lives handwritten in types.d.ts - see doc/typescript.md
 */
export type ContractConfig = import("./types.js").ContractConfig;
/**
 * The type vocabulary lives handwritten in types.d.ts - see doc/typescript.md
 */
export type AdditionalValidations = import("./types.js").AdditionalValidations;
/**
 * The type vocabulary lives handwritten in types.d.ts - see doc/typescript.md
 */
export type ErrorNode = import("./types.js").ErrorNode;
/**
 * The type vocabulary lives handwritten in types.d.ts - see doc/typescript.md
 */
export type FlatError = import("./types.js").FlatError;
/**
 * The type vocabulary lives handwritten in types.d.ts - see doc/typescript.md
 */
export type ContractClass = import("./types.js").ContractClass;
import { SchemaError } from "./schema-lint.js";
